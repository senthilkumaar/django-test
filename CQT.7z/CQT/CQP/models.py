from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    mapped_to = models.CharField(max_length=100)
    is_admin = models.BooleanField(default=False)
    db_insert = models.BooleanField(default=False)
    db_delete = models.BooleanField(default=False)
    db_update = models.BooleanField(default=False)
    db_view = models.BooleanField(default=False)
	
class AssociatedDB(models.Model):
    #user = models.OneToOneField(User, null=True, on_delete=models.SET_NULL)
    created_by = models.CharField(max_length=100)
    db_name = models.CharField(max_length=100)
    db_host = models.CharField(max_length=20)
    db_username = models.CharField(max_length=50)
    db_password = models.CharField(max_length=100)

class QueryPost(models.Model):
    db = models.OneToOneField(AssociatedDB, null=True, on_delete=models.SET_NULL)
    author = models.CharField(max_length=10)
    query_string = models.TextField()
    query_title = models.CharField(max_length=100)
    query_desc = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now)

# Create your models here.
