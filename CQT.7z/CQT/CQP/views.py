from django.shortcuts import render, redirect
from .models import User, Profile, QueryPost, AssociatedDB
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .utils import *

def AuthLogin(request, user):
	login(request, user)
	user_details = Profile.objects.get(user=user.id)
	request.session['logged_in'] = True
	request.session['username'] = user.username
	request.session['is_admin'] = user_details.is_admin
	request.session['db_insert'] = user_details.db_insert
	request.session['db_update'] = user_details.db_update
	request.session['db_delete'] = user_details.db_delete
	request.session['db_view'] = user_details.db_view

def home(request):
    if request.method == 'POST':
        uname = request.POST.get('uname')
        password = request.POST.get('password')
        user = authenticate(username=uname, password=password)
        if user:
            user_details = Profile.objects.get(user=user.id)
            AuthLogin(request, user)
            if user_details.is_admin:
	            return redirect('/CQP/admin_page')
            else:
	            return redirect('/CQP/querry_page')
	
        else:
            messages.warning(request, 'Invalid Login')
            return render(request, 'home.html', {'invalid':'invalid login'})
    else:
        if 'logged_in' in request.session:
            if request.session['is_admin'] == True:
                return redirect('/CQP/admin_page')
            else:
                return redirect('/CQP/querry_page')
        else:
            return render(request, 'home.html', {})
    return render(request, 'home.html', {})

@login_required(login_url='/CQP/')
def admin_page(request):
    if not request.session['is_admin']:
        return redirect("/CQP")
    user = User.objects.get(username=request.session['username'])
    user_details = Profile.objects.get(user=user.id)
    msg = {'msg':'Hello %s' %(user.username)}
    mapped_users = Profile.objects.filter(mapped_to=user.username)
    users = []
    databases = []
    for mu in mapped_users:
        #mu_details = User.objects.get(user=mu.users.id)
        users.append({'username':mu.user.username, 'admin_status':mu.is_admin})
    dbs = AssociatedDB.objects.filter(created_by=request.session['username'])
    for db in dbs:
        databases.append({'db_name':db.db_name, 'host':db.db_host, 'username':db.db_username})
    return render(request, 'admin_page.html', {'mapped_users':users, 'mapped_dbs':databases})

@login_required(login_url="/CQP")
def add_user(request):
    if not request.session['is_admin']:
        messages.warning(request, 'Access Denied!')
        return redirect('/CQP')
    if request.method == 'POST':
        username = request.POST.get("username")
        email = request.POST.get("email")
        password = username+"Cisco"
        u = User.objects.filter(username=username)
        if u:
            messages.info(request, "User already exists")
            return redirect("/CQP/add_user")
        user = User.objects.create_user(username, email, password)
        p = Profile.objects.create(user=user, mapped_to=request.session['username'])
        messages.info(request, "User created")
        return redirect("/CQP/admin_page")
    return render(request, 'add_user.html', {})

@login_required(login_url="/CQP")
def add_database(request):
    if not request.session['is_admin']:
        messages.warning(request, 'Access Denied!')
        return redirect('/CQP')
    if request.method == 'POST':
        db_name = request.POST.get('db_name')
        db_host = request.POST.get('db_host')
        db_user = request.POST.get('db_user')
        db_password = request.POST.get('db_password')
        database = AssociatedDB.objects.filter(created_by=request.session['username'], db_host=db_host, db_username=db_user)
        if database:
            messages.info(request, "Database already exists")
            return redirect("/CQP/add_database")
        db = AssociatedDB.objects.create(created_by=request.session['username'], db_name=db_name, db_host=db_host, db_username=db_user, db_password=db_password)
        messages.info(request, "Database added!")
        return redirect("/CQP")
    return render(request, 'add_database.html', {})		

@login_required(login_url='/CQP')
def querry_page(request):
    user = User.objects.get(username=request.session['username'])
    user_details = Profile.objects.get(user=user.id)
    db_list = AssociatedDB.objects.filter(created_by=user_details.mapped_to)
    db_details = []
    for db in db_list:
        db_details.append({'db_name':db.db_name, 'db_host':db.db_host, 'db_user':db.db_username})
    return render(request, 'querry_page.html', {'db_details':db_details})

'''
@login_required(login_url='/')
def search_page(request, db_name, db_host, db_user):
    db_details = AssociatedDB.object.filter(db_name=db_name, db_host=db_host, db_username=db_user)
    if db_details:
'''            

@login_required(login_url='/')
def LogoutUser(request):
    logout(request)
    return redirect('/CQP')
# Create your views here.
