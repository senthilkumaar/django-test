def db_connect():
    return None