from django.apps import AppConfig


class CqpConfig(AppConfig):
    name = 'CQP'
