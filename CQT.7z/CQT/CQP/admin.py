from django.contrib import admin
from .models import Profile, AssociatedDB, QueryPost

admin.site.register(Profile)
admin.site.register(AssociatedDB)
admin.site.register(QueryPost)


# Register your models here.
